INSERT INTO Tipo_de_Auto VALUES('Sedan');
INSERT INTO Tipo_de_Auto VALUES('Pick up');
INSERT INTO Tipo_de_Auto VALUES('Subcompacto');
INSERT INTO Tipo_de_Auto VALUES('Deportivo');
INSERT INTO Tipo_de_Auto VALUES('Compacto');
--INSERT INTO Tipo_de_Auto VALUES('Automóvil de lujo');
INSERT INTO Tipo_de_Auto VALUES('Lujo');
INSERT INTO Tipo_de_Auto VALUES('SUV');