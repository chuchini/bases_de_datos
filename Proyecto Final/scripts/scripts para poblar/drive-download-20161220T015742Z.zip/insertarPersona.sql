


INSERT INTO Persona VALUES ('PAFC730423A', 'Cristian', 'Pastor', 'Flores', 'M', 'cr.paflo44@gmail.com' , '1973-04-23' );
INSERT INTO Persona VALUES ('ROVE690711B', 'Eva Maria', 'Rodriguez', 'Vargas', 'F', 'eva.rodriguev21@msn.com', '1969-07-11');
INSERT INTO Persona VALUES ('SEGJ611112C', 'Jaime','Serrano', 'Gil', 'M', 'jai.serr6@gmail.com', '1961-11-12');
INSERT INTO Persona VALUES ('GADM940619D', 'Maria', 'Gallego', 'Delgado', 'F', 'm.galldelgad@facebook.com', '1994-06-19');
INSERT INTO Persona VALUES ('TOFI520228E', 'Ismael', 'Torres', 'Flores', 'M', 'is_torreflore53@gmail.com', '1952-02-28');
INSERT INTO Persona VALUES ('GABF651004F', 'Fernando', 'Garrido', 'Bravo', 'M', 'fernan-garrbr92@msn.com', '1965-10-04');
INSERT INTO Persona VALUES ('MOMA890211G', 'Aurora', 'Mora', 'Mu�oz', 'F', 'a.morm@msn.com', '1989-02-11');
INSERT INTO Persona VALUES ('SEVL851106H', 'Luis', 'Serrano', 'Vidal', 'M', 'l_sevid57@facebook.com', '1985-11-06');
INSERT INTO Persona VALUES ('VENJ650730I', 'Jose Carlos', 'Vega', 'Nieto', 'M', 'josvn@facebook.com', '1965-07-30');
INSERT INTO Persona VALUES ('MARM461104J', 'Manuela', 'Martin', 'Romero','F', 'mrom@msn.com', '1946-11-04');
INSERT INTO Persona VALUES ('VAND611211K', 'Domingo', 'Vargas', 'Navarro', 'M', 'dom_vnava79@ciencias.unam.mx', '1961-12-11');
INSERT INTO Persona VALUES ('GOSP320108L', 'Purificacion', 'Gomez', 'Soto','F', 'purificacio_74@facebook.com', '1932-01-08');
INSERT INTO Persona VALUES ('SAMP510724M', 'Paula', 'Sanchez', 'Moreno','F', 'pau_more@facebook.com', '1951-07-24');
INSERT INTO Persona VALUES ('MEGY810606N', 'Yolanda', 'Mendez', 'Garcia','F', 'yolandmgar@ciencias.unam.mx', '1981-06-05');
INSERT INTO Persona VALUES ('CACM771127O', 'Maria Josefa', 'Castro', 'Cruz','F', 'mariacastrcr@gmail.com', '1977-11-27');
INSERT INTO Persona VALUES ('REBF760706P', 'Felix','Reyes', 'Blanco', 'M', 'f_reyebl@unam.mx', '1976-07-06');
INSERT INTO Persona VALUES ('CEMA920514Q', 'Alberto', 'Crespo', 'Montero', 'M', 'acres23@live.com', '1992-05-14');
INSERT INTO Persona VALUES ('COTA850430R', 'Alberto', 'Cortes', 'Torres', 'M', 'albtorr68@msn.com', '1985-04-30');
INSERT INTO Persona VALUES ('CACR951127S', 'Ruben', 'Calvo', 'Cabrera', 'M', 'r_calvcabrer@live.com', '1995-11-27');
INSERT INTO Persona VALUES ('DIFV681101T', 'Victor Manuel', 'Diez', 'Fuentes', 'M', 'victor.dief59@gmail.com', '1968-11-01');