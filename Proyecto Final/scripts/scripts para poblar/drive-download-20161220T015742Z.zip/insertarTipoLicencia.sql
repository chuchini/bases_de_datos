INSERT INTO Tipo_de_Licencia VALUES ('Tipo A');
INSERT INTO Tipo_de_Licencia VALUES ('Tipo B');
INSERT INTO Tipo_de_Licencia VALUES ('Tipo C');
INSERT INTO Tipo_de_Licencia VALUES ('Tipo D');
INSERT INTO Tipo_de_Licencia VALUES ('Tipo E');
INSERT INTO Tipo_de_Licencia VALUES ('Tipo F');