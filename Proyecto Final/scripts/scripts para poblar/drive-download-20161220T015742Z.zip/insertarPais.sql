



INSERT INTO Pais VALUES ('Mexico');
INSERT INTO Pais VALUES ( 'Italia');
INSERT INTO Pais VALUES ('Japon');
INSERT INTO Pais VALUES ('Estados Unidos');
INSERT INTO Pais VALUES ( 'Alemania');
INSERT INTO Pais VALUES ( 'Corea del Sur');
INSERT INTO Pais VALUES ('Francia');
INSERT INTO Pais VALUES ('Reino Unido');
INSERT INTO Pais VALUES ( 'Suecia');