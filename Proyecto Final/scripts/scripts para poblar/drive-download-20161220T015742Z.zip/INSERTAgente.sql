INSERT INTO Agente (sSector, sRFC) VALUES 
('sector oasis', 'PAFC730423A'),
('sector omega', 'ROVE690711B');
