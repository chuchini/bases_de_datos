
INSERT INTO Transmision VALUES ('Manual');
INSERT INTO Transmision VALUES ('Automatica');
INSERT INTO Transmision VALUES ('Ambas');
--INSERT INTO Transmision VALUES ('Manual y Automatica');
--INSERT INTO Transmision VALUES ('Semiautomatica');