


INSERT INTO Telefono VALUES ('5-03-28-35', '0');
INSERT INTO Telefono VALUES ('5-26-06-54', '1');
INSERT INTO Telefono VALUES ('8-55-36-27', '1');
INSERT INTO Telefono VALUES ('4-93-01-24', '1');
INSERT INTO Telefono VALUES ('5-39-54-42', '1');
INSERT INTO Telefono VALUES ('6-79-83-72', '1');
INSERT INTO Telefono VALUES ('4-66-61-34', '0');
INSERT INTO Telefono VALUES ('8-57-80-79', '1');
INSERT INTO Telefono VALUES ('2-09-59-09', '1');
INSERT INTO Telefono VALUES ('6-96-81-78', '1');
INSERT INTO Telefono VALUES ('5-54-96-33', '1');
INSERT INTO Telefono VALUES ('1-58-62-68', '1');
INSERT INTO Telefono VALUES ('5-74-55-75', '1');
INSERT INTO Telefono VALUES ('2-39-78-80', '1');
INSERT INTO Telefono VALUES ('2-58-79-37', '1');
INSERT INTO Telefono VALUES ('3-97-39-00', '0');
INSERT INTO Telefono VALUES ('7-47-58-33', '1');
INSERT INTO Telefono VALUES ('6-94-91-19', '1');
INSERT INTO Telefono VALUES ('6-29-34-85', '1');
INSERT INTO Telefono VALUES ('4-10-48-51', '1');
INSERT INTO Telefono VALUES ('2-55-06-69', '1');
INSERT INTO Telefono VALUES ('6-88-26-32', '1');
INSERT INTO Telefono VALUES ('3-50-48-01', '1');
INSERT INTO Telefono VALUES ('7-18-62-36', '1');
INSERT INTO Telefono VALUES ('1-90-15-12', '0');
INSERT INTO Telefono VALUES ('9-66-51-86', '1');
INSERT INTO Telefono VALUES ('8-72-57-42', '1');
INSERT INTO Telefono VALUES ('3-99-85-54', '1');
INSERT INTO Telefono VALUES ('9-34-44-15', '1');
INSERT INTO Telefono VALUES ('9-39-06-26', '1');