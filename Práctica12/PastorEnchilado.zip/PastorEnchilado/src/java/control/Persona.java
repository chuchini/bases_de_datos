/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 *
 * @author chuch
 */
import java.util.ArrayList;

/**
 *
 * @author erick
 */
public class Persona extends Control{

    int id;
    private String app;
    private String apm;
    private String nombre;
    private String fecha_nac;
    private String correo;
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }
    
    public String getApm() {
        return apm;
    }

    public void setApm(String apm) {
        this.apm = apm;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFecha_nac() {
        return fecha_nac;
    }

    public void setFecha_nac(String fecha_nac) {
        this.fecha_nac = fecha_nac;
    }
    
    public String getCorreo() {
        return this.correo;
    }
    
    public void setCorreo(String correo) {
        this.correo = correo;
    }
          
    public ArrayList getPersonas() throws Exception{
        ArrayList personas = new ArrayList();
        try{
            personas = conexionBD.getPersonas();
        }catch(Exception ex){
            System.out.println("No se pudieron recuperar las personas " + ex.getMessage());
        }
        return personas;
    }
    
    public int setPersona(String app, String apm, String nombre, String fecha, String correo) throws Exception{
        int b = 0;
        try{
            b = conexionBD.setPersona(app, apm, nombre, fecha, correo);
        }catch(Exception ex){
            System.out.println("No se pudo registrar a la Persona " + ex.getMessage());
        }
        return b;
    }
}
