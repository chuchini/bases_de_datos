/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 *
 * @author Usuario
 */
public class PersonaTelefono extends Control{
    private int nIdPersona;
    private int nIdTelefono;
    private int bActivo;
    private int nIdTipoTelefono;

    /**
     * @return the nIdPersona
     */
    public int getnIdPersona() {
        return nIdPersona;
    }

    /**
     * @param nIdPersona the nIdPersona to set
     */
    public void setnIdPersona(int nIdPersona) {
        this.nIdPersona = nIdPersona;
    }

    /**
     * @return the nIdTelefono
     */
    public int getnIdTelefono() {
        return nIdTelefono;
    }

    /**
     * @param nIdTelefono the nIdTelefono to set
     */
    public void setnIdTelefono(int nIdTelefono) {
        this.nIdTelefono = nIdTelefono;
    }

    /**
     * @return the bActivo
     */
    public int getbActivo() {
        return bActivo;
    }

    /**
     * @param bActivo the bActivo to set
     */
    public void setbActivo(int bActivo) {
        this.bActivo = bActivo;
    }

    /**
     * @return the nIdTipoTelefono
     */
    public int getnIdTipoTelefono() {
        return nIdTipoTelefono;
    }

    /**
     * @param nIdTipoTelefono the nIdTipoTelefono to set
     */
    public void setnIdTipoTelefono(int nIdTipoTelefono) {
        this.nIdTipoTelefono = nIdTipoTelefono;
    }
    
    public int setPersonaTelefono(int activo, int tipoTelefono) throws Exception{
        int b = 0;
        try{
            b = conexionBD.setPersonaTelefono(activo, tipoTelefono);
        }catch(Exception ex){
            System.out.println("No se pudo registrar el Telefono " + ex.getMessage());
        }
        return b;
    }
}
