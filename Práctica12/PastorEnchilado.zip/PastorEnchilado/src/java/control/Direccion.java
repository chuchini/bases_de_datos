/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 *
 * @author Usuario
 */
public class Direccion extends Control {
    private int idDireccion;
    private String calle;
    private String colonia;
    private String cp;
    private String observaciones;
    private int nIdMunicipio;

    /**
     * @return the idDireccion
     */
    public int getIdDireccion() {
        return idDireccion;
    }

    /**
     * @param idDireccion the idDireccion to set
     */
    public void setIdDireccion(int idDireccion) {
        this.idDireccion = idDireccion;
    }

    /**
     * @return the calle
     */
    public String getCalle() {
        return calle;
    }

    /**
     * @param calle the calle to set
     */
    public void setCalle(String calle) {
        this.calle = calle;
    }

    /**
     * @return the colonia
     */
    public String getColonia() {
        return colonia;
    }

    /**
     * @param colonia the colonia to set
     */
    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    /**
     * @return the cp
     */
    public String getCp() {
        return cp;
    }

    /**
     * @param cp the cp to set
     */
    public void setCp(String cp) {
        this.cp = cp;
    }

    /**
     * @return the observaciones
     */
    public String getObservaciones() {
        return observaciones;
    }

    /**
     * @param observaciones the observaciones to set
     */
    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }
    
    /**
     * @return the nIdMunicipio
     */
    public int getnIdMunicipio() {
        return nIdMunicipio;
    }

    /**
     * @param nIdMunicipio the nIdMunicipio to set
     */
    public void setnIdMunicipio(int nIdMunicipio) {
        this.nIdMunicipio = nIdMunicipio;
    }
    
    /**
     * Establece los datos que se mandarán a la base de datos.
     * @param calle
     * @param colonia
     * @param cp
     * @param observaciones
     * @param activo
     * @param municipio
     * @param idEstado
     * @return
     * @throws Exception 
     */
    public int setDireccion(String calle, String colonia, String cp, String observaciones, int activo, String municipio, String idEstado) throws Exception{
        int b = 0;
        try{
            b = conexionBD.setDireccion(calle, colonia, cp, observaciones, activo, municipio, idEstado);
        }catch(Exception ex){
            System.out.println("No se pudo registrar la Dirección " + ex.getMessage());
        }
        return b;
    }

    
    
    
}
