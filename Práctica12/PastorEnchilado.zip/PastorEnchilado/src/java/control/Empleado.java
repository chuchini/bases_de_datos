/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.util.ArrayList;

/**
 *
 * @author chuch
 */
public class Empleado extends Persona{
    private int idEmpleado;
    private String fechaContratacion;
    private String rfc;
    private boolean activo;
    private String tipoEmpleado;
    
    public int getIdEmpleado() {
        return idEmpleado;
    }
    
    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }
    
    public String getFechaContratacion() {
        return fechaContratacion;
    }
    
    public void setFechaContratacion(String fechaContratacion) {
        this.fechaContratacion = fechaContratacion;
    }
    
    public String getRfc() {
        return rfc;
    }
    
    public void setRfc(String rfc) {
        this.rfc = rfc;
    }
    
    public boolean getActivo() {
        return activo;
    }
    
    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public String getTipoEmpleado() {
        return tipoEmpleado;
    }

    public void setTipoEmpleado(String tipoEmpleado) {
        this.tipoEmpleado = tipoEmpleado;
    }
    
    public ArrayList getEmpleados() throws Exception {
        ArrayList empleados = new ArrayList();
        try {
            empleados = conexionBD.getEmpleados();
        } catch(Exception ex) {
            System.out.println("No se pudieron recuperar los empleados");
    }
        return empleados;
    }
}