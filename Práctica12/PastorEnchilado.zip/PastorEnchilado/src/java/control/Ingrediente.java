/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 *
 * @author Usuario
 */
public class Ingrediente extends Control {
    private int nIdIngrediente;
    private String sIngrediente;
    private int bActivo;

    /**
     * @return the nIdIngrediente
     */
    public int getnIdIngrediente() {
        return nIdIngrediente;
    }

    /**
     * @param nIdIngrediente the nIdIngrediente to set
     */
    public void setnIdIngrediente(int nIdIngrediente) {
        this.nIdIngrediente = nIdIngrediente;
    }

    /**
     * @return the sIngrediente
     */
    public String getsIngrediente() {
        return sIngrediente;
    }

    /**
     * @param sIngrediente the sIngrediente to set
     */
    public void setsIngrediente(String sIngrediente) {
        this.sIngrediente = sIngrediente;
    }

    /**
     * @return the bActivo
     */
    public int getbActivo() {
        return bActivo;
    }

    /**
     * @param bActivo the bActivo to set
     */
    public void setbActivo(int bActivo) {
        this.bActivo = bActivo;
    }
    
    /**
     * Establece los datos que se mandarán a la base de datos.
     * @param ingrediente
     * @param activo
     * @return 
     */
    public int setIngrediente(String ingrediente, int activo) {
        int b = 0;
        try{
            b = conexionBD.setIngrediente(ingrediente, activo);
        }catch(Exception ex){
            System.out.println("No se pudo registrar la al Proveedor del Ingrediente " + ex.getMessage());
        }
        return b;
        
    }
}
