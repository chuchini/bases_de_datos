/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.util.ArrayList;

/**
 *
 * @author chuch
 */
public class Orden extends Control{
    private int IdOrden;
    private double total;
    private String fecha;
    private int idEmpleado;
    private int idDia;

    public int getIdOrden() {
        return IdOrden;
    }

    public void setIdOrden(int IdOrden) {
        this.IdOrden = IdOrden;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getFecha() {
        return fecha;
    }
    
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public int getIdDia() {
        return idDia;
    }

    public void setIdDia(int idDia) {
        this.idDia = idDia;
    }
    
    /**
     * 
     * @return
     * @throws Exception 
     */
    public ArrayList getOrdenes() throws Exception{
        ArrayList ordenes = new ArrayList();
        try{
            ordenes = conexionBD.getHistorialDeOrdenes();
        }catch(Exception ex){
            System.out.println("No se pudieron recuperar las ordenes " + ex.getMessage());
        }
        return ordenes;
    }
    
    /**
     * 
     * @param id
     * @return
     * @throws Exception 
     */
    public Orden getOrden(int id) throws Exception {
        Orden orden = new Orden();
        try {
            orden = conexionBD.getOrden(id);
        } catch(Exception ex) {
            System.out.println("No se pudo recuperar la orden " + ex.getMessage());
        }
        return orden;
    }
}
