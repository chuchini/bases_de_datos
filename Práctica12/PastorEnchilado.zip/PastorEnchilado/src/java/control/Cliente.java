/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.util.ArrayList;

/**
 *
 * @author chuch
 */
public class Cliente extends Persona{
    private int idCliente;
    private String monedero;
    private double saldo;
    private String fecha_reg;
    private boolean activo;
    
    public int getIdCliente(){
        return idCliente;
    }
    
    public void setIdCliente(int idCliente){
        this.idCliente = idCliente;
    }
    
    public String getMonedero() {
        return monedero;
    }
    
    public void setMonedero(String monedero) {
        this.monedero = monedero;
    }
    
    public double getSaldo(){
        return saldo;
    }
    
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public String getFecha_reg() {
        return fecha_reg;
    }
    
    public void setFecha_reg(String fecha_reg) {
        this.fecha_reg = fecha_reg;
    }
    
    public boolean getActivo() {
        return activo;
    }
    
    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    public ArrayList getClientes() throws Exception{
        ArrayList clientes = new ArrayList();
        try{
            clientes = conexionBD.getClientes();
        }catch(Exception ex){
            System.out.println("No se pudieron recuperar los clientes " + ex.getMessage());
        }
        return clientes;
    }
    
    /**
     * Establece los datos que se mandarán a la base de datos.
     * @param monedero
     * @param saldo
     * @param fecha_hoy
     * @param activo
     * @return
     * @throws Exception 
     */
    public int setCliente(String monedero, double saldo, String fecha_hoy, int activo) throws Exception{
        int b = 0;
        try{
            b = conexionBD.setCliente(monedero, saldo, fecha_hoy, activo);
        }catch(Exception ex){
            System.out.println("No se pudo registrar el Cliente " + ex.getMessage());
        }
        return b;
    }
}
