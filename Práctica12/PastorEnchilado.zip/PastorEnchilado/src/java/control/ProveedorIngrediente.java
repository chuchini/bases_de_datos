/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 *
 * @author Usuario
 */
public class ProveedorIngrediente extends Control {
    private int nIdProveedorIngrediente;
    private String dFecha;
    private double dCosto;
    private String dCantidad;
    private int nIdProveedor;
    private int nIdIngrediente;
    private int nIdSucursal;

    /**
     * @return the nIdProveedorIngrediente
     */
    public int getnIdProveedorIngrediente() {
        return nIdProveedorIngrediente;
    }

    /**
     * @param nIdProveedorIngrediente the nIdProveedorIngrediente to set
     */
    public void setnIdProveedorIngrediente(int nIdProveedorIngrediente) {
        this.nIdProveedorIngrediente = nIdProveedorIngrediente;
    }

    /**
     * @return the dFecha
     */
    public String getdFecha() {
        return dFecha;
    }

    /**
     * @param dFecha the dFecha to set
     */
    public void setdFecha(String dFecha) {
        this.dFecha = dFecha;
    }

    /**
     * @return the dCosto
     */
    public double getdCosto() {
        return dCosto;
    }

    /**
     * @param dCosto the dCosto to set
     */
    public void setdCosto(double dCosto) {
        this.dCosto = dCosto;
    }

    /**
     * @return the dCantidad
     */
    public String getdCantidad() {
        return dCantidad;
    }

    /**
     * @param dCantidad the dCantidad to set
     */
    public void setdCantidad(String dCantidad) {
        this.dCantidad = dCantidad;
    }

    /**
     * @return the nIdProveedor
     */
    public int getnIdProveedor() {
        return nIdProveedor;
    }

    /**
     * @param nIdProveedor the nIdProveedor to set
     */
    public void setnIdProveedor(int nIdProveedor) {
        this.nIdProveedor = nIdProveedor;
    }

    /**
     * @return the nIdIngrediente
     */
    public int getnIdIngrediente() {
        return nIdIngrediente;
    }

    /**
     * @param nIdIngrediente the nIdIngrediente to set
     */
    public void setnIdIngrediente(int nIdIngrediente) {
        this.nIdIngrediente = nIdIngrediente;
    }

    /**
     * @return the nIdSucursal
     */
    public int getnIdSucursal() {
        return nIdSucursal;
    }

    /**
     * @param nIdSucursal the nIdSucursal to set
     */
    public void setnIdSucursal(int nIdSucursal) {
        this.nIdSucursal = nIdSucursal;
    }
    
    /**
     * Establece los datos que se mandarán a la base de datos.
     * @param fecha
     * @param costo
     * @param cantidad
     * @param nombreSuc
     * @return 
     */
    public int setProveedorIngrediente(String fecha, double costo, String cantidad, String nombreSuc) {
        int b = 0;
        try{
            b = conexionBD.setProveedorIngrediente(fecha, costo, cantidad, nombreSuc);
        }catch(Exception ex){
            System.out.println("No se pudo registrar la al Proveedor del Ingrediente " + ex.getMessage());
        }
        return b;
        
    }
}
