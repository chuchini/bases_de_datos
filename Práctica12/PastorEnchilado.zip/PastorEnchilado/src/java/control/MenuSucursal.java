/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.util.ArrayList;

/**
 *
 * @author chuch
 */
public class MenuSucursal extends Control {
    private String sucursal;
    private String producto;

    public String getSucursal() {
        return sucursal;
    }

    public void setSucursal(String sucursal) {
        this.sucursal = sucursal;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }
    
    public ArrayList getMenuSucursales() throws Exception {
        ArrayList menu_suc = new ArrayList();
        try {
            menu_suc = conexionBD.getMenuSucursales();  
        } catch(Exception ex) {
            System.out.println("No se pudieron recuperar los productos de las sucursales.");
    }
        return menu_suc;
    }
}
