/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.util.ArrayList;

/**
 *
 * @author chuch
 */
public class DetalleOrden extends Control {
    private int idDetalleOrden;
    private int cantidad;
    private boolean aDomicilio;
    private int idSucursalProducto;
    private int idOrden;
    private int idCliente;
    
    public int getIdDetalleOrden() {
        return idDetalleOrden;
    }

    public void setIdDetalleOrden(int idDetalleOrden) {
        this.idDetalleOrden = idDetalleOrden;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public boolean getADomicilio() {
        return aDomicilio;
    }

    public void setADomicilio(boolean aDomicilio) {
        this.aDomicilio = aDomicilio;
    }

    public int getIdSucursalProducto() {
        return idSucursalProducto;
    }

    public void setIdSucursalProducto(int idSucursalProducto) {
        this.idSucursalProducto = idSucursalProducto;
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }
    
    public ArrayList getDetalleOrdenes() throws Exception{
        ArrayList detalleOrdenes = new ArrayList();
        try{
            detalleOrdenes = conexionBD.getDetalleOrdenes();
        }catch(Exception ex){
            System.out.println("No se pudieron recuperar los detalles de las ordenes " + ex.getMessage());
        }
        return detalleOrdenes;
    }
    
}
