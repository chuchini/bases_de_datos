/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.util.ArrayList;

/**
 *
 * @author chuch
 */
public class Sucursal extends Control{
    private int idSucursal;
    private String nombreSuc;
    private boolean aDomicilio;
    private boolean activo;
    private String tipoSucursal;
    private String calle;
    private String colonia;
    private String cp;
    private String estado;
    private String municipio;
    
    public int getIdSucursal() {
        return idSucursal;
    }
    
    public void setIdSucursal(int idSucursal) {
        this.idSucursal = idSucursal;
    }
    
    public String getNombreSuc() {
        return nombreSuc;
    }
    
    public void setNombreSuc(String nombreSuc) {
        this.nombreSuc = nombreSuc;
    }
    
    public boolean getADomicilio() {
        return aDomicilio;
    }
    
    public void setADomicilio(boolean aDomicilio) {
        this.aDomicilio = aDomicilio;
    }
    
    public boolean getActivo() {
        return activo;
    }
    
    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public String getTipoSucursal() {
        return tipoSucursal;
    }

    public void setTipoSucursal(String tipoSucursal) {
        this.tipoSucursal = tipoSucursal;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getColonia() {
        return colonia;
    }

    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    public String getCp() {
        return cp;
    }

    public void setCp(String cp) {
        this.cp = cp;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }
    
    
    
    public ArrayList getSucursales() throws Exception{
        ArrayList sucursales = new ArrayList();
        try{
            sucursales = conexionBD.getSucursales();
        }catch(Exception ex){
            System.out.println("No se pudieron recuperar las sucursales " + ex.getMessage());
        }
        return sucursales;
    }
}
