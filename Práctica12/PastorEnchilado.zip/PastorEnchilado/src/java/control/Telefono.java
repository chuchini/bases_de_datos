/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 *
 * @author Usuario
 */
public class Telefono extends Control {
    private int nIdTelefono;
    private String sTelefono;
    private int bActivo;

    /**
     * @return the nIdTelefono
     */
    public int getnIdTelefono() {
        return nIdTelefono;
    }

    /**
     * @param nIdTelefono the nIdTelefono to set
     */
    public void setnIdTelefono(int nIdTelefono) {
        this.nIdTelefono = nIdTelefono;
    }

    /**
     * @return the sTelefono
     */
    public String getsTelefono() {
        return sTelefono;
    }

    /**
     * @param sTelefono the sTelefono to set
     */
    public void setsTelefono(String sTelefono) {
        this.sTelefono = sTelefono;
    }

    /**
     * @return the bActivo
     */
    public int getbActivo() {
        return bActivo;
    }

    /**
     * @param bActivo the bActivo to set
     */
    public void setbActivo(int bActivo) {
        this.bActivo = bActivo;
    }
    
    public int setTelefono(String telefono, int activo) throws Exception{
        int b = 0;
        try{
            b = conexionBD.setTelefono(telefono, activo);
        }catch(Exception ex){
            System.out.println("No se pudo registrar el Telefono " + ex.getMessage());
        }
        return b;
    }
    
}
