/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 *
 * @author chuch
 */
public class CategoriaProducto {
    private int nIdCategoria;
    private String categoria;

    public int getnIdCategoria() {
        return nIdCategoria;
    }

    public void setnIdCategoria(int nIdCategoria) {
        this.nIdCategoria = nIdCategoria;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
    
}
