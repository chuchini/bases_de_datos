/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.util.ArrayList;

/**
 *
 * @author chuch
 */
public class HistorialDeOrdenes extends Cliente {
    private int idOrden;
    private double total;
    private int cantidad;
    private String producto;

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }
    
    public ArrayList getHistorialDeOrdenes() throws Exception {
        ArrayList hist_ord = new ArrayList();
        try {
            hist_ord = conexionBD.getHistorialDeOrdenes();
        } catch(Exception ex) {
            System.out.println("No se pudieron recuperar las ordenes");
    }
        return hist_ord;
    }
}
