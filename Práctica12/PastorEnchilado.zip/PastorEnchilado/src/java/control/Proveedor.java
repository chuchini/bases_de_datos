/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

/**
 *
 * @author chuch
 */
public class Proveedor extends Control {
    private int idProveedor;
    private String proveedor;
    private String rfc;
    private boolean activo;
    
    public int getIdProveedor() {
        return idProveedor;
    }
    
    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }
    
    public String getProveedor() {
        return proveedor;
    }
    
    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }
    
    public String getRfc() {
        return rfc;
    }
    
    public void setRfc(String rfc) {
        this.rfc = rfc;
    }
    
    public boolean getActivo() {
        return activo;
    }
    
    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    /**
     * Establece los datos que se mandarán a la base de datos.
     * @param nombre
     * @param rfc
     * @param activo
     * @return
     * @throws Exception 
     */
    public int setProveedor(String nombre, String rfc, int activo) throws Exception{
        int b = 0;
        try{
            b = conexionBD.setProveedor(nombre, rfc, activo);
        }catch(Exception ex){
            System.out.println("No se pudo registrar el Proveedor " + ex.getMessage());
        }
        return b;
    }
}
