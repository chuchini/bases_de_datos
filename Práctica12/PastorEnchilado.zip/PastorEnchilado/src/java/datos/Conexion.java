/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;

import control.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author erick
 */
public class Conexion {
    
    //Creamos nuestros objetos para la comunicacion y ejecucion de codigo SQL
    private Connection con;
    private Statement stmt;
    private ResultSet rs;
    
    //Constructor    
    public Conexion() {
        stmt = null;
        con = null;
        rs = null;
    }

    /*
     * Metodo que nos permite abrir la conexion con una base de datos 
     * especificada en el parametro de entrada del metodo que ha sido
     * invocado en la capa de Control
     * @author  Erick Matla
     * @version 1.0
     * @param   nombrebase - nombre de la base de datos a la cual nos 
     *          conectaremos
     */
    public void conectar()
            throws Exception {
        
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectionUrl = "jdbc:sqlserver://localhost;" +
                                    "database=pastorenchilado;" +
                                    "user=sa;" +
                                    "password=8624"; 
            con = DriverManager.getConnection(connectionUrl);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("SQLException: " + e.getMessage() + " conectar =(");
        }
    }

    /*
     * Metodo que nos permite cerrar la conexion con una base de datos 
     * el metodo debe ser invocado en la capa de Control
     * @author  Erick Matla
     * @version 1.0
     * @param   sin parametros     
     */
    public void desconectar()
            throws SQLException {
        try {
            con.close();
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage() + " desconectar =(");
        }
    }
    
    public ArrayList getPersonas() throws Exception {
        ArrayList personas = new ArrayList();

        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT nIdPersona, sApp, sApm, sNombre, dFechaNacimiento, sCorreo FROM persona;");
            while (rs.next()) {
                Persona p = new Persona();
                p.setId(rs.getInt(1));
                p.setApp(rs.getString(2));
                p.setApm(rs.getString(3));
                p.setNombre(rs.getString(4));
                p.setFecha_nac(rs.getString(5));
                p.setCorreo(rs.getString(6));
                personas.add(p);
            }
            rs.close();
            stmt.close();
        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage() + " getPersonas");
        }
        return personas;
    }
    
    public int setEstado(String estado) throws SQLException {
        int b = 0;
        try {
            stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO CEstado(sestado) VALUES ('" + estado + "');");
            b = 1;
            stmt.close();
        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage() + " getActivaSede =(");
        }
        return b;
    }
    
    /**
     * Inserta los datos en la tabla Direccion en la base de datos.
     * @param calle
     * @param colonia
     * @param cp
     * @param observaciones
     * @return
     * @throws SQLException 
     */
    public int setDireccion(String calle, String colonia, String cp, String observaciones) throws SQLException {
        int b = 0;
        try {
            stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO Direccion(sCalle, sColonia, sCp, sObservaciones, bActivo) VALUES ('" + calle + "','" + colonia + "','" + cp + "','" + observaciones + "'," + 1 + " );");
            b = 1;
            stmt.close();
        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage() + " getActivaSede =(");
        }
        return b;
    }
    
    /**
     * Inserta los datos en la tabla Proveedor de la base de datos.
     * @param nombre
     * @param rfc
     * @param activo
     * @return
     * @throws SQLException 
     */
    public int setProveedor(String nombre, String rfc, int activo) throws SQLException {
        int b = 0;
        try {
            stmt = con.createStatement();
            
            rs = stmt.executeQuery("SELECT MAX(nIdDireccion) FROM Direccion;");
            int idDireccion = 1;
            while(rs.next()){
                idDireccion = rs.getInt(1);
            }
            
            stmt.executeUpdate("INSERT INTO Proveedor(sProveedor, sRFC, bActivo, nIdDireccion) VALUES ('" + nombre + "','" + rfc + "', " + activo + ", " + idDireccion + ");");
            b = 1;
            stmt.close();
        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage() + " getActivaSede =(");
        }
        return b;
    }
    
    /**
     * Inserta los datos en la tabla Persona de la base de datos.
     * @param app
     * @param apm
     * @param nombre
     * @param fecha
     * @param correo
     * @return
     * @throws SQLException 
     */
    public int setPersona(String app, String apm, String nombre, String fecha, String correo) throws SQLException {
        int b = 0;
        try {
            stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO Persona(sApp, sApm, sNombre, dFechaNacimiento, sCorreo) VALUES ('" + app + "', '" + apm + "', '" + nombre + "', '" + fecha + "', '" + correo + "');");
            b = 1;
            stmt.close();
        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage() + " getActivaSede =(");
        }
        return b;
    }
    
    /**
     * Inserta los datos en la tabla Cliente de la base de datos.
     * @param monedero
     * @param saldo
     * @param fecha_hoy
     * @param activo
     * @return
     * @throws SQLException 
     */
    public int setCliente(String monedero, double saldo, String fecha_hoy, int activo) throws SQLException {
        int b = 0;
        try {
            stmt = con.createStatement();
            
            rs = stmt.executeQuery("SELECT MAX(nIdPersona) FROM Persona;");
            int idPersona = 1;
            while(rs.next()){
                idPersona = rs.getInt(1);
            }
            
            String saldoS = "$"+String.valueOf(saldo);
            
            stmt.executeUpdate("INSERT INTO Cliente(sMonedero, mSaldo, dFechaRegistro, bActivo, nIdPersona) VALUES ('" + monedero + "', '" + saldo + "', '" + fecha_hoy + "', " + activo + ", " + idPersona + ");");
            b = 1;
            stmt.close();
        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage() + " getActivaSede =(");
        }
        return b;
    }
    
    /**
     * Inserta los datos en la tabla Telefono de la base de datos.
     * @param telefono
     * @param activo
     * @return
     * @throws SQLException 
     */
    public int setTelefono(String telefono, int activo) throws SQLException {
        int b = 0;
        try {
            stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO Telefono(sTelefono, bActivo) VALUES ('" + telefono + "', " + activo + ");");
            b = 1;
            stmt.close();
        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage() + " getActivaSede =(");
        }
        return b;
    }
    
    /**
     * Inserta los datos en la tabla Persona_Telefono de la base de datos.
     * @param activo
     * @param tipoTelefono
     * @return
     * @throws SQLException 
     */
    public int setPersonaTelefono(int activo, int tipoTelefono) throws SQLException {
        int b = 0;
        try {
            stmt = con.createStatement();
            
            rs = stmt.executeQuery("SELECT MAX(nIdPersona) FROM Persona;");
            int idPersona = 1;
            while(rs.next()){
                idPersona = rs.getInt(1);
            }
            
            rs = stmt.executeQuery("SELECT MAX(nIdTelefono) FROM Telefono;");
            int idTelefono = 1;
            while(rs.next()){
                idTelefono = rs.getInt(1);
            }
            
            stmt.executeUpdate("INSERT INTO Persona_Telefono(nIdPersona, nIdTelefono, bActivo, nIdTipoTelefono) VALUES (" + idPersona + ", " + idTelefono + ", " + activo + ", " + tipoTelefono + ");");
            b = 1;
            stmt.close();
        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage() + " getActivaSede =(");
        }
        return b;
    }
    
    /**
     * Inserta los datos en la tabla Direccion de la base de datos
     * a partir del id del municipio.
     * @param calle
     * @param colonia
     * @param cp
     * @param observaciones
     * @param activo
     * @param municipio
     * @param idEstado
     * @return
     * @throws SQLException 
     */
    public int setDireccion(String calle, String colonia, String cp, String observaciones, int activo, String municipio, String idEstado) throws SQLException {
        int b = 0;
        try {
            stmt = con.createStatement();
            int nIdEstado = Integer.parseInt(idEstado);
            
            rs = stmt.executeQuery("SELECT nIdMunicipio FROM CMunicipio WHERE sMunicipio LIKE '"+municipio+"' AND nIdEstado = " +nIdEstado+";");
            int idMunicipio = 1;
            while(rs.next()){
                idMunicipio = rs.getInt(1);
            }
            
            stmt.executeUpdate("INSERT INTO Direccion(sCalle, sColonia, sCp, sObservaciones, bActivo, nIdMunicipio) VALUES ('" + calle + "', '" + colonia + "', '" + cp + "', '" + observaciones + "', " + activo + ", " + idMunicipio + ");");
            b = 1;
            stmt.close();
        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage() + " getActivaSede =(");
        }
        return b;
    }
    
    /**
     * Inserta los datos en la tabla Ingrediente de la base de datos.
     * @param ingrediente
     * @param activo
     * @return
     * @throws SQLException 
     */
    public int setIngrediente(String ingrediente, int activo) throws SQLException {
        int b = 0;
        try {
            stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO Ingrediente(sIngrediente, bActivo) VALUES ('" + ingrediente + "', " + activo + ");");
            b = 1;
            stmt.close();
        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage() + " getActivaSede =(");
        }
        return b;
    }
    
    /**
     * Inserta los datos en la tabla Proveedor_Ingrediente de la base de datos.
     * @param fecha
     * @param costo
     * @param cantidad
     * @param nombreSuc
     * @return 
     */
    public int setProveedorIngrediente(String fecha, double costo, String cantidad, String nombreSuc) {
        int b = 0;
        try {
            stmt = con.createStatement();
            String mCosto = "$"+String.valueOf(costo);
            
            rs = stmt.executeQuery("SELECT MAX(nIdProveedor) FROM Proveedor;");
            int idProveedor = 1;
            while(rs.next()){
                idProveedor = rs.getInt(1);
            }
            
            rs = stmt.executeQuery("SELECT MAX(nIdIngrediente) FROM Ingrediente;");
            int idIngrediente = 1;
            while(rs.next()){
                idIngrediente = rs.getInt(1);
            }
            
            rs = stmt.executeQuery("SELECT nIdSucursal FROM Sucursal WHERE sNombre LIKE '" + nombreSuc + "';");
            int idSucursal = 1;
            while(rs.next()){
                idSucursal = rs.getInt(1);
            }
            
            
            stmt.executeUpdate("INSERT INTO Proveedor_Ingrediente(dFecha, mCosto, sCantidad, nIdProveedor, nIdIngrediente, nIdSucursal) VALUES ('" + fecha + "', '" + mCosto + "', '" + cantidad + "', " + idProveedor + ", " + idIngrediente + ", " + idSucursal + ");");
            b = 1;
            stmt.close();
        } catch (SQLException ex) {
            System.err.println("SQLException: " + ex.getMessage() + " getActivaSede =(");
        }
        return b;
    }
    
    /**
     *
     * @return @throws Exception
     */
    public ArrayList getClientes() throws Exception {
        ArrayList clientes = new ArrayList();

        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT Persona.nIdPersona, sApp, sApm, sNombre, dFechaNacimiento, sCorreo, nIdCliente, sMonedero, "
                    + "mSaldo, dFechaRegistro, bActivo FROM Persona "
                    + "INNER JOIN Cliente ON Persona.nIdPersona = Cliente.nIdPersona;");
            while (rs.next()) {
                Cliente c = new Cliente();
                c.setId(rs.getInt(1));
                c.setApp(rs.getString(2));
                c.setApp(rs.getString(3));
                c.setNombre(rs.getString(4));
                c.setFecha_nac(rs.getString(5));
                c.setCorreo(rs.getString(6));
                c.setIdCliente(rs.getInt(7));
                c.setMonedero(rs.getString(8));
                c.setSaldo(rs.getDouble(9));
                c.setFecha_reg(rs.getString(10));
                c.setActivo(rs.getBoolean(11));
                clientes.add(c);
            }
            rs.close();
            stmt.close();
        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage() + " getClientes");
        }
        return clientes;
    }
    
    /**
    * 
    * @return
    * @throws Exception 
    */
    public ArrayList getEmpleados() throws Exception {
        ArrayList empleados = new ArrayList();

        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT sTipoEmpleado, sNombre, sApp, dFechaNacimiento, sCorreo, dFechaContratacion, sRFC, bActivo FROM Persona\n" +
                                   "INNER JOIN Empleado ON Persona.nIdPersona = Empleado.nIdPersona\n" +
                                   "INNER JOIN CTipo_Empleado ON Empleado.nIdTipoempleado = CTipo_Empleado.nIdTipoEmpleado\n" +
                                   "GROUP BY sTipoEmpleado, sNombre, sApp, dFechaNacimiento, sCorreo, dFechaContratacion, sRFC, bActivo\n" +
                                   "ORDER BY sTipoEmpleado;");
            while (rs.next()) {
                Empleado e = new Empleado();
                e.setTipoEmpleado(rs.getString(1));
                e.setNombre(rs.getString(2));
                e.setApp(rs.getString(3));
                e.setFecha_nac(rs.getString(4));
                e.setCorreo(rs.getString(5));
                e.setFechaContratacion(rs.getString(6));
                e.setRfc(rs.getString(7));
                e.setActivo(rs.getBoolean(8));
                empleados.add(e);
            }
            rs.close();
            stmt.close();
        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage() + " getEmpleados");
        }
        return empleados;
    }
    
    /**
     * 
     * @return
     * @throws Exception 
     */
    public ArrayList getSucursales() throws Exception {
        ArrayList sucursales = new ArrayList();

        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT nIdSucursal, sNombre, bAdomicilio, s.bActivo, sTipoSucursal, sCalle, sColonia, sCp, sEstado, sMunicipio FROM Sucursal s\n" +
                                   "INNER JOIN CTipo_Sucursal ts ON s.nIdTipoSucursal = ts.nIdTipoSucursal\n" +
                                   "INNER JOIN Direccion d ON s.nIdDireccion = d.nIdDireccion\n" +
                                   "INNER JOIN CMunicipio m ON d.nIdMunicipio = m.nIdMunicipio\n" +
                                   "INNER JOIN CEstado e ON m.nIdEstado = e.nIdEstado\n" +
                                   "GROUP BY nIdSucursal, sNombre, bAdomicilio, s.bActivo, sTipoSucursal, sCalle, sColonia, sCp, sEstado, sMunicipio\n" +
                                   "ORDER BY sEstado;");
            while (rs.next()) {
                Sucursal s = new Sucursal();
                s.setIdSucursal(rs.getInt(1));
                s.setNombreSuc(rs.getString(2));
                s.setADomicilio(rs.getBoolean(3));
                s.setActivo(rs.getBoolean(4));
                s.setTipoSucursal(rs.getString(5));
                s.setCalle(rs.getString(6));
                s.setColonia(rs.getString(7));
                s.setCp(rs.getString(8));
                s.setEstado(rs.getString(9));
                s.setMunicipio(rs.getString(10));
                sucursales.add(s);
            }
            rs.close(); 
            stmt.close();
        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage() + " getSucursales");
        }
        return sucursales;
    }
    
    public ArrayList getHistorialDeOrdenes() throws Exception {
        ArrayList hist_ord = new ArrayList();

        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT Orden.nIdOrden, sNombre, sApp, mTotal, nCantidad, sProducto\n" +
                                   "FROM Persona INNER JOIN Cliente ON  Persona.nIdPersona = Cliente.nIdPersona\n" +
                                   "INNER JOIN DetalleOrden ON Cliente.nIdCliente = DetalleOrden.nIdCliente\n" +
                                   "INNER JOIN Orden ON DetalleOrden.nIdOrden = Orden.nIdOrden\n" +
                                   "INNER JOIN Sucursal_Producto ON DetalleOrden.nIdSucursalProducto = Sucursal_Producto.nIdSucursalProducto\n" +
                                   "INNER JOIN Producto ON Sucursal_Producto.nIdProducto = Producto.nIdProducto;");
            while (rs.next()) {
                HistorialDeOrdenes ho = new HistorialDeOrdenes();
                ho.setIdOrden(rs.getInt(1));
                ho.setNombre(rs.getString(2));
                ho.setApp(rs.getString(3));
                ho.setTotal((double) rs.getDouble(4));
                ho.setCantidad(rs.getInt(5));
                ho.setProducto(rs.getString(6));
                hist_ord.add(ho);
            }
            rs.close();
            stmt.close();
        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage() + " gerOrdenes");
        }
        return hist_ord;
    }
    
    public ArrayList getMenuSucursales() throws Exception {
        ArrayList productos = new ArrayList();

        try {
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT sNombre, sProducto FROM Sucursal INNER JOIN Sucursal_Producto ON Sucursal.nIdSucursal = Sucursal_Producto.nIdSucursal\n" +
                                   "INNER JOIN Producto ON Sucursal_Producto.nIdProducto = Producto.nIdProducto\n" +
                                   "GROUP BY sNombre, sProducto\n" +
                                   "ORDER BY sNombre;");
            while (rs.next()) {
                MenuSucursal ms = new MenuSucursal();
                ms.setSucursal(rs.getString(1));
                ms.setProducto(rs.getString(2));
                productos.add(ms);
            }
            rs.close();
            stmt.close();
        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage() + " getMenuSucursales");
        }
        return productos;
    }
}
